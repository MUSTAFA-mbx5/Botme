import os
import logging
from telethon import TelegramClient, events
import openai # تحتاج تثبيت مكتبة OpenAI: pip install openai
import asyncio # لاستخدامه في التأخير بين الرسائل الكبيرة

# إعدادات تسجيل الدخول لتليجرام
# احصل عليها من my.telegram.org
API_ID = 16504919  # استبدل هذا بالـ API ID الخاص بك
API_HASH = 'e9ddbc4aa70093979dcc2d20153fba08' # استبدل هذا بالـ API Hash الخاص بك

# مفتاح API لخدمة الذكاء الاصطناعي (مثال: OpenAI)
# احصل عليه من منصة الخدمة (مثال: platform.openai.com)
OPENAI_API_KEY = 'sk-...' # استبدل هذا بمفتاح OpenAI API الخاص بك

# اسم ملف الجلسة (يمكنك اختيار أي اسم)
SESSION_NAME = 'my_telegram_session'

# إعدادات الأوامر
COMMAND_PREFIX = '.' # البادئة التي تبدأ بها الأوامر
REPORT_COMMAND = 'تقرير' # الأمر الخاص بكتابة التقرير

# متغير لتخزين ID صاحب الحساب (سيتم تحديثه بعد الاتصال)
OWNER_ID = None

# ----------------------------------------------

# إعداد تسجيل الأحداث (اختياري للمساعدة في تتبع المشاكل)
logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
                    level=logging.WARNING) # يمكنك تغييرها إلى logging.INFO لرؤية تفاصيل أكثر

# إعداد عميل تليجرام
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

# إعداد مكتبة OpenAI
openai.api_key = OPENAI_API_KEY

# ----------------------------------------------

# دالة للتواصل مع الذكاء الاصطناعي والحصول على التقرير
async def get_ai_report(topic: str) -> str:
    """تتواصل مع OpenAI لكتابة تقرير شامل عن موضوع محدد."""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", # يمكنك تغيير النموذج إلى "gpt-4" أو غيره إذا كان لديك وصول
            messages=[
                {"role": "system", "content": "أنت مساعد متخصص في كتابة تقارير شاملة ومفصلة عن مواضيع مختلفة باللغة العربية."},
                {"role": "user", "content": f"اكتب تقريراً شاملاً ومفصلاً عن: {topic}\nيرجى كتابة التقرير باللغة العربية."},
            ],
            max_tokens=3000, # زيد القيمة لتقرير أطول (انتبه للتكلفة وحدود النموذج)
            temperature=0.7,
        )
        report_text = response.choices[0].message['content'].strip()
        return report_text

    except openai.error.AuthenticationError:
        logging.error("OpenAI Authentication Error: Invalid API Key or insufficient credits.")
        return "خطأ: مفتاح OpenAI API غير صالح أو لا يوجد رصيد كافٍ."
    except openai.error.RateLimitError:
         logging.error("OpenAI Rate Limit Error: Too many requests or exceeding rate limits.")
         return "خطأ: تجاوز الحد الأقصى لعدد الطلبات (Rate Limit)."
    except openai.error.Timeout:
        logging.error("OpenAI API request timed out.")
        return "خطأ: انتهت مهلة طلب خدمة الذكاء الاصطناعي."
    except openai.error.APIError as e:
        logging.error(f"OpenAI API error: {e}")
        return f"حدث خطأ في API الخاص بخدمة الذكاء الاصطناعي: {e}"
    except Exception as e:
        logging.error(f"An unexpected error occurred during AI request: {e}")
        return f"حدث خطأ غير متوقع أثناء طلب التقرير: {e}"

# ----------------------------------------------

# معالج الرسائل الجديدة
# *** التعديل هنا: إزالة outgoing=True ***
@client.on(events.NewMessage(pattern=f'^{COMMAND_PREFIX}{REPORT_COMMAND}(.*)', forwards=False))
async def handle_report_command(event):
    """يستمع للأمر '.تقرير اسم الموضوع' ويقوم بإنشاء وإرسال التقرير."""

    # *** التعديل هنا: إضافة التحقق من هوية المرسل ***
    global OWNER_ID # نستخدم المتغير العام الذي يخزن ID صاحب الحساب
    if event.sender_id != OWNER_ID:
        # إذا كان المرسل ليس هو صاحب الحساب، تجاهل الأمر
        # يمكنك إرسال رسالة إخبارية إذا أردت، مثال:
        # await event.reply("عذراً، هذا الأمر متاح فقط لصاحب الحساب.")
        return # توقف عن معالجة الرسالة

    # بقية الكود لمعالجة الأمر كما كان سابقاً

    chat = await event.get_chat() # الحصول على معلومات المحادثة
    topic = event.pattern_match.group(1).strip() # استخراج الموضوع

    if not topic:
        await event.reply(f"الرجاء تحديد الموضوع الذي تريد كتابة تقرير شامل عنه بعد الأمر `{COMMAND_PREFIX}{REPORT_COMMAND}`.")
        return

    logging.info(f"تلقى الأمر: {COMMAND_PREFIX}{REPORT_COMMAND} للموضوع: {topic} من المالك.")

    # إرسال رسالة مبدئية للمستخدم لإعلامه بأن العملية جارية
    processing_message = await event.reply(f"جارٍ كتابة تقرير شامل عن: **{topic}**...\nيرجى الانتظار قليلاً.")

    # طلب التقرير من الذكاء الاصطناعي
    report = await get_ai_report(topic)

    # بعد الحصول على التقرير، قم بإرساله إلى المستخدم
    if report.startswith("حدث خطأ") or report.startswith("خطأ:"):
         # إذا كان الرد هو رسالة خطأ من دالة get_ai_report
         await processing_message.edit(f"**فشل في كتابة التقرير:** {report}")
    else:
        # تقسيم الرسالة إذا كانت طويلة جداً (لحدود تليجرام)
        max_length = 4000 # أقل بقليل من الحد الأقصى ليكون آمناً
        if len(report) > max_length:
            parts = [report[i:i+max_length] for i in range(0, len(report), max_length)]
            # إرسال الجزء الأول بتعديل الرسالة المبدئية
            await processing_message.edit(f"**التقرير عن: {topic}** (الجزء 1):\n{parts[0]}")
            # إرسال الأجزاء المتبقية كرسائل جديدة
            for i, part in enumerate(parts[1:]):
                 await client.send_message(chat, f"**التقرير عن: {topic}** (الجزء {i+2}):\n{part}")
                 await asyncio.sleep(0.5) # إضافة تأخير بسيط بين الرسائل الكبيرة
        else:
            # إذا كان التقرير ضمن الحد الأقصى للطول، قم بتعديل الرسالة المبدئية
            await processing_message.edit(f"**التقرير عن: {topic}**:\n{report}")


# ----------------------------------------------

# وظيفة تشغيل العميل
async def main():
    global OWNER_ID # لكي نتمكن من تعديل المتغير العام OWNER_ID

    print("جاري الاتصال بحساب تليجرام...")
    await client.start()

    # *** التعديل هنا: الحصول على معلومات صاحب الحساب وتخزين ID ***
    me = await client.get_me()
    OWNER_ID = me.id # تخزين معرف صاحب الحساب لتستخدمه في التحقق لاحقاً

    print(f"تم الاتصال بنجاح بحساب: {me.username or me.first_name}")
    print(f"معرف صاحب الحساب (Owner ID): {OWNER_ID}") # مفيد للمراجعة
    print(f"البوت يعمل الآن. أرسل الأمر '{COMMAND_PREFIX}{REPORT_COMMAND} اسم الموضوع' في أي محادثة لديك.")

    # إبقاء العميل يعمل حتى يتم قطع الاتصال
    await client.run_until_disconnected()
    print("تم قطع الاتصال.")


# نقطة الدخول الرئيسية للسكريبت
if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("تم إيقاف البوت يدوياً.")