import os
import asyncio
import math
import fitz  # PyMuPDF
import docx
import pptx
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.errors.rpcerrorlist import MessageDeleteForbiddenError # Import for better error handling on delete
from telethon.tl.types import PeerUser, MessageMediaPhoto, MessageMediaDocument # Import specific types for clearer checks
from datetime import datetime, timedelta # Import for date and time handling
import sys # Import sys for graceful exit attempts
import traceback # Import for printing full error traceback
import glob # Import glob for finding files

# معلومات API وتفاصيل الجلسة
API_ID = 16504919
API_HASH = 'e9ddbc4aa70093979dcc2d20153fba08'
# تأكد من استبدال هذا بسلسلة الجلسة الخاصة بك
# NOTE: If you are getting the session string interactively elsewhere,
# ensure this variable is correctly set before running the bot.
SESSION_STRING = '1ApWapzMBu6HhI9AI8AEpvwAmkTYSC4Q6-VpkO8vS3EOj8No1YNGK-NNWkuOPxwtw1c9arESslmS1NPreNh8NfVIA2OIgY1ZW14TCBwGYJRFh-ZyGPwXrZwblLMuj6wfKKfDrvi0jq5QRbvEFK_p_QvAZwDfr_MCZ6BH9aYlijkKkOcqiC3sTbM_cn33lXSDOTzduVBlB1i7UmrIW96ofprdsmcVdUb1ToO-PiSkEgqinhAMbwkQm4R6oBOVuYxWUkVypHjcxUAFsnsDXrpFBGrUKl2O6ptXQojNLAanO0luQWi8EA3kQj-gOflpVtptQEaLONh-iShKNfpPulEQTnrcx1u2WAWg='

# Define TelegramClient globally BEFORE any @client.on decorators
# This ensures the 'client' variable is defined when decorators are processed
client = TelegramClient(StringSession(SESSION_STRING), API_ID, API_HASH)

# الدردشة التي سيتم إرسال التنبيهات إليها (المحفوظة 'me' هي مكان جيد)
NOTIFICATION_CHAT = 'me' # يمكن تغييره إلى معرف دردشة آخر إذا أردت

# Global state variables
# False = كاعد (مستعد), True = نايم (غير متاح)
is_sleeping = False

# user_id: dict of {message_id: (base_price, cover_price)}
# This maps the message ID of the file/image to its calculated prices
# Prices accumulate here until the bot restarts.
user_prices = {}

# user_id: message_object (to track and delete previous status messages)
user_status_messages = {}
# user_id: datetime object (to track last time welcome was sent or interaction happened)
user_last_interaction_time = {}
# Set of user_ids to ignore (blocked by owner)
ignored_users = set()
# Bot's own user ID, will be set after client.start()
bot_id = None

# State for handling image type question (user_id: {'image_count': int, 'question_message_id': int, 'original_message_id': int})
user_image_state = {}

# Global total collected for daily report (resets on bot restart, or daily report send)
global_daily_total_collected = 0

# Global variable to store the bot's start time (for uptime calculation)
bot_start_time = None

# Global variable to hold the daily report task object (for checking its state)
daily_report_task = None


# Configuration for file size limit (in bytes) - Adjust as needed
# 50MB limit example (50 * 1024 * 1024)
MAX_FILE_SIZE = 50 * 1024 * 1024 # Approximately 50MB

# Configurable Prices (Global Variables) - New
PRICE_PER_PAGE_LT50 = 50
PRICE_PER_PAGE_GTE50 = 40
COVER_BINDING_COST = 500 # سعر الجلاد (يضاف عند طلب الجلاد)
PRICE_PER_IMAGE_LT10 = 200 # سعر الصورة اقل او يساوي ١٠
PRICE_PER_IMAGE_GTE10 = 100 # سعر الصورة اكثر من ١٠

# Define messages as constants for easier management and updates
WELCOME_MESSAGE = "👋 أهلاً بك في بوت حساب أسعار الطباعة! أرسل لي ملف PDF, DOCX, أو PPTX أو صورة وسأقوم بحساب السعر لك. يمكنك إرسال أي رسالة نصية أخرى بعد إرسال الملفات للحصول على المجموع الكلي."
WELCOME_COOLDOWN = timedelta(hours=12) # Define the 12-hour cooldown period for welcome message
APOLOGY_MESSAGE = "اعتذار، صاحب المكتبة غير موجود حالياً. يرجى المحاولة في وقت لاحق."
WAITING_MESSAGE = "شكرًا لرسالتك. سيتم الرد عليك بأقرب وقت ممكن."
CALCULATING_MESSAGE = "⏳ جار احتساب... يرجى الانتظار." # Simplified calculating message
FILE_TYPE_ERROR_MESSAGE = "⚠️ يرجى إرسال ملف PDF، DOCX، PPTX أو صورة فقط." # Updated for images
FILE_SIZE_ERROR_MESSAGE = f"⚠️ حجم الملف يتجاوز الحد المسموح به ({MAX_FILE_SIZE // (1024*1024)} ميجابايت). يرجى إرسال ملف أصغر."
COUNT_PAGES_ERROR_MESSAGE = "❌ لا يمكن معالجة هذا الملف: لم يتمكن البوت من قراءة عدد الصفحات أو الملف تالف." # More specific error
PROCESSING_ERROR_MESSAGE = "❌ حدث خطأ أثناء معالجة الملف. يرجى المحاولة مرة أخرى." # Simplified general error for user
MUTE_SUCCESS_MESSAGE = "✅ تم سماح (تجاهل رسائل هذا المستخدم)." # Simple confirmation for muting
UNMUTE_SUCCESS_MESSAGE = "✅ تم الغاء السماح (إلغاء تجاهل رسائل هذا المستخدم)." # Simple confirmation for unmuting
USER_NOT_IGNORED_MESSAGE = "هذا المستخدم ليس في قائمة التجاهل أصلاً."
IMAGE_QUESTION_MESSAGE = "هل هذه الصورة/الصور دراسية أم شخصية؟ أجب بـ `A` لدراسية أو `B` لشخصية." # Question for images
IMAGE_STUDY_CONFIRMATION = "✅ تم احتساب {count} صورة دراسية بسعر {price} دينار. تم إضافة المبلغ للمجموع الكلي الخاص بك." # Confirmation for study images
IMAGE_PERSONAL_CONFIRMATION = "✅ تم تسجيل اختيار صور شخصية. يرجى الانتظار ليرد عليك صاحب الحساب لتحديد القياس والسعر." # Confirmation for personal images
DAILY_REPORT_MESSAGE_TEMPLATE = "📊 التقرير اليومي ({date}):\nالمجموع الكلي للمبالغ التي تم عرضها للمستخدمين خلال الـ 24 ساعة الماضية: {total} دينار." # Template for daily report
# Removed ONLY_PRIVATE_MESSAGE as the group handler is being removed

PRICE_UPDATE_SUCCESS_TEMPLATE = "✅ تم تحديث `{price_name}` إلى {new_price} دينار." # Message for price update
PRICE_UPDATE_ERROR = "❌ خطأ في تعديل السعر. يرجى التأكد من الأمر والقيمة العددية (مثال: `.ت1 60`)." # Message for price update error
PRICE_UPDATE_INVALID_VALUE = "❌ القيمة المدخلة غير صحيحة. يرجى إدخال قيمة عددية صحيحة (مثال: `.ت1 60`)." # Message for price update invalid value

CUMULATIVE_TOTAL_MESSAGE_TEMPLATE = (
    "📊 المجموع الكلي للملفات المرسلة حتى الآن:\n"
    "بدون جلاد: {total_base} دينار\n"
    "مع جلاد: {total_cover} دينار\n"
    "🙏 شكرًا لطلبك." # Message for cumulative total
)


# Template for the commands list message (uses the global price variables when formatted)
COMMANDS_LIST_MESSAGE_TEMPLATE = (
    "📋 قائمة الأوامر:\n"
    "\n"
    "🔹 أوامر حالة البوت (تُستخدم في المحفوظة):\n"
    "  `.نايم` - لتفعيل وضع النوم (البوت يرد باعتذار على كل الرسائل).\n"
    "  `.كاعد` - لتفعيل وضع الاستعداد (البوت يرد برسالة انتظار أو يحسب السعر).\n"
    "  `.م` - لعرض قائمة الأوامر هذه.\n"
    "  `.تفعيل` - عرض حالة البوت، مدة التشغيل، وعدد المستخدمين المتفاعلين.\n" # Added .تفعيل
    "  `.فحص` - إجراء فحص أساسي لحالة البوت وتبليغ عن أي مشاكل.\n" # Added .فحص
    "\n"
    "🔹 أوامر تعديل الأسعار (تُستخدم في المحفوظة):\n"
    "  `.ت1 <قيمة>` - تعديل سعر الصفحة (للملفات < 50 صفحة). القيمة الحالية: {price_lt50}\n"
    "  `.ت2 <قيمة>` - تعديل سعر الصفحة (للملفات >= 50 صفحة). القيمة الحالية: {price_gte50}\n"
    "  `.ت3 <قيمة>` - تعديل ضريبة الجلاد (تضاف لكل ملف/صورة). القيمة الحالية: {cover_cost}\n"
    "  `.ت4 <قيمة>` - تعديل سعر الصورة (لعدد الصور <= 10). القيمة الحالية: {img_lt10}\n"
    "  `.ت5 <قيمة>` - تعديل سعر الصورة (لعدد الصور > 10). القيمة الحالية: {img_gte10}\n"
    "\n"
    "🔹 أوامر إدارة المستخدمين (تُستخدم في محادثة المستخدم الخاصة بواسطة مالك البوت):\n"
    "  `.سماح` - لتجاهل رسائل هذا المستخدم (البوت يتوقف عن الرد عليه).\n"
    "  `.الغاء` - لإلغاء تجاهل رسائل هذا المستخدم.\n"
    "  `.عرض` - لعرض المجموع الكلي لملفاته المرسلة حتى الآن.\n" # Updated command description
    "\n"
    "🔹 ملاحظات إضافية:\n"
    "  - البوت يعمل فقط في المحادثات الخاصة (مع المستخدمين).\n" # Added clarity about private chat only
    "  - المجموع الكلي يظهر تلقائياً بعد معالجة كل ملف أو صورة دراسية وبعد حذف أي منهم.\n" # Clarified how total is sent
    "  - عند إرسال صورة، سيتم سؤالك عما إذا كانت دراسية (A) أم شخصية (B) لاحتساب السعر بشكل صحيح.\n"
    "  - حذف رسالة ملف أو صورة دراسية سيؤدي إلى خصم سعرها من المجموع الكلي المخزن.\n"
    "  - هناك تقرير يومي للمبالغ المجمعة يتم إرساله إلى المحفوظة.\n"
    "  - حجم الملفات (بما في ذلك الصور) محدود بـ {max_size_mb} ميجابايت.\n"
    "\n"
    "⚠️ ملاحظة: الأوامر التي تبدأ بنقطة (.) هي أوامر خاصة بمالك البوت وتستخدم في المحادثات المخصصة (المحفوظة أو المحادثة الخاصة مع المستخدم)."
)


# دالة لتقريب السعر إلى أقرب 250 دينار
def round_up_to_250(x):
    return int(math.ceil(x / 250.0) * 250)

# دالة لحساب السعر الأساسي وسعر الجلاد لعدد معين من الصفحات أو سعر الصور
# Returns a tuple (base_price, cover_price)
def calculate_price(count, is_image=False):
    if is_image:
        price_per_unit = PRICE_PER_IMAGE_LT10 if count <= 10 else PRICE_PER_IMAGE_GTE10
        calculated_price = count * price_per_unit
        # Base price for images does NOT include cover binding cost
        base_price = round_up_to_250(calculated_price)
        # Cover price for images DOES include cover binding cost
        cover_price = round_up_to_250(calculated_price + COVER_BINDING_COST)
        return (base_price, cover_price)
    else:
        pages = count # Renaming for clarity when it's page count
        price_per_page = PRICE_PER_PAGE_LT50 if pages < 50 else PRICE_PER_PAGE_GTE50
        base_price = pages * price_per_page
        # Base price for documents does NOT include cover binding cost
        base_price_rounded = round_up_to_250(base_price)
        # Cover price for documents DOES include cover binding cost
        cover_price_rounded = round_up_to_250(base_price + COVER_BINDING_COST)
        return (base_price_rounded, cover_price_rounded)


# دالة مساعدة لتشغيل الدوال المتزامنة (مثل فتح الملفات) في مؤشر ترابط منفصل
# هذا يمنع تعطيل حلقة الأحداث الرئيسية (event loop) أثناء معالجة الملفات
# يستخدم asyncio.to_thread (متاح في Python 3.9+)
async def run_sync_in_thread(func, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)


# دالة لحساب عدد الصفحات/الشرائح
# This function is called AFTER the file is downloaded.
# It only handles documents. Image counting is done in handle_media.
async def count_pages_for_document(file_path, ext):
    try:
        if ext == '.pdf':
            doc = await run_sync_in_thread(fitz.open, file_path)
            pages = len(doc)
            doc.close() # Closing is usually fast
            return pages
        elif ext == '.docx':
            doc = await run_sync_in_thread(docx.Document, file_path)
            paragraphs = await run_sync_in_thread(lambda d: list(d.paragraphs), doc) # Convert to list in thread
            return max(1, len(paragraphs) // 10)
        elif ext == '.pptx':
            pres = await run_sync_in_thread(pptx.Presentation, file_path)
            slides = await run_sync_in_thread(lambda p: list(p.slides), pres) # Convert iterator to list in thread
            return len(slides)
        # Return 0 for unsupported extensions reaching here (shouldn't happen if called correctly)
        return 0

    except Exception as e:
        print(f"Error counting pages for {file_path}: {e}")
        traceback.print_exc() # Print traceback for counting errors
        return 0 # Return 0 on error

# --- Async Function to Send Cumulative Total ---
async def send_cumulative_total(user_id, chat_id):
    """Calculates and sends the current cumulative total for a user."""
    # Declare global variable used for daily report
    global global_daily_total_collected, user_prices # user_prices is read here

    user_prices_dict = user_prices.get(user_id, {}) # Get the dict for user_id, default to empty dict if none
    total_base = sum(p[0] for p in user_prices_dict.values())
    total_cover = sum(p[1] for p in user_prices_dict.values())

    # Only send the total message if there are items priced for this user
    if total_base > 0 or total_cover > 0:
        reply_text = CUMULATIVE_TOTAL_MESSAGE_TEMPLATE.format(
            total_base=total_base,
            total_cover=total_cover
        )
        try:
            # Send the total message to the user's chat
            await client.send_message(chat_id, reply_text)
            print(f"Sent cumulative total ({total_base}/{total_cover} IQD) for user {user_id} to chat {chat_id}.")
            # Add the base total reported to the global daily total *only when the USER sees the total*
            # This happens after file processing, study image confirmation, or deletion.
            global_daily_total_collected += total_base
            print(f"Added {total_base} IQD to daily total for user {user_id}. Current daily total: {global_daily_total_collected}")

        except Exception as e:
            print(f"Error sending cumulative total to user {user_id} in chat {chat_id}: {e}")
            traceback.print_exc()
    else:
        # Optional: Send a message indicating no items are pending if the total is 0
        # print(f"No items priced for user {user_id} after update/deletion. Skipping total message.")
        pass # Remain silent if no items pending


# --- Async Function to Send Telegram Notification ---
# This function will use the main 'client' instance
async def send_notification(message):
    """Sends a message to the configured notification chat using the main bot client."""
    global bot_id # Declare global variable

    print(f"Attempting to send notification to '{NOTIFICATION_CHAT}': {message}")
    # Ensure bot_id is set before attempting to send
    if bot_id is None:
        print("Warning: bot_id not set, trying to get it for notification.")
        # Try connecting client explicitly if bot_id is None, just in case start failed partially
        # This part is tricky if called from a crashed state/closed loop.
        # The asyncio.run(send_crash_notification_temp()) in main() handles creating a new loop.
        # This function is mainly for notifications *while* the bot is running normally.
        try:
             if not client.is_connected():
                 print("Client not connected, trying to connect for notification (during normal operation)...")
                 await client.connect()
                 # Try getting bot_id again if connect was successful
                 me = await client.get_me()
                 # global bot_id # Already declared at function start - REMOVED
                 bot_id = me.id
                 print(f"Notification sender connected, bot_id set to {bot_id}.")
             else:
                 # If connected but bot_id is None, try getting it
                 me = await client.get_me()
                 # global bot_id # Already declared at function start - REMOVED
                 bot_id = me.id
                 print(f"Client already connected, bot_id set to {bot_id}.")

        except Exception as e:
             print(f"Failed to connect client or get bot_id for notification (during normal operation): {e}")
             traceback.print_exc() # Print error details for debugging
             # Cannot send notification if client fails to connect/get bot_id
             return # Exit function if cannot connect

    # If bot_id is set (either was set initially or after connecting above)
    if bot_id is not None:
        try:
            # Send the message using the global client instance
            await client.send_message(NOTIFICATION_CHAT, message)
            print("Notification sent successfully.")
        except Exception as e:
            print(f"Error sending notification to '{NOTIFICATION_CHAT}': {e}")
            traceback.print_exc() # Print error details for debugging
    else:
        print("Warning: bot_id is still None after connection attempt (during normal operation), cannot send notification.")


# --- Periodic task to report daily total ---
async def report_daily_total():
    # Declare global variables
    global global_daily_total_collected, bot_id, daily_report_task # Include daily_report_task if needed inside

    # Wait until bot_id is set (client is started)
    while bot_id is None:
         await asyncio.sleep(1)
         # print("Waiting for bot_id to be set for daily report task...") # Log waiting state


    print("Daily report task started.")
    while True:
        # Sleep for 24 hours (in seconds)
        await asyncio.sleep(24 * 60 * 60)
        # await asyncio.sleep(60) # For testing: report every 60 seconds

        print("Attempting to send daily report...")
        if global_daily_total_collected > 0:
            report_date = datetime.now().strftime("%Y-%m-%d") # Format date
            report_text = DAILY_REPORT_MESSAGE_TEMPLATE.format(date=report_date, total=global_daily_total_collected)
            try:
                # Send to Saved Messages ('me') using the global client instance
                await client.send_message('me', report_text)
                print(f"Daily report sent successfully: {global_daily_total_collected} IQD")
                # Reset the total after reporting successfully
                global_daily_total_collected = 0
            except Exception as e:
                print(f"Failed to send daily report to Saved Messages: {e}")
                traceback.print_exc() # Print traceback for report errors
                # If sending fails, the total is not reset, it will be included in the next report attempt.
        else:
             print("No new total collected in the last 24 hours. Skipping daily report.")


# --- REMOVED: Handler for Owner Replies (Resets user_prices) ---
# This handler was triggered by owner replies in private chat and cleared user history.
# It is removed as per user request to keep history until bot restart.
# @client.on(events.NewMessage(outgoing=True, func=lambda e: e.reply_to_msg_id is not None and e.is_private))
# async def handle_owner_reply(event):
#     pass # Function removed


# --- Handlers for state commands in Saved Messages ---
# Use outgoing=True for commands sent by the owner to Saved Messages
@client.on(events.NewMessage(chats='me', pattern='^\.نايم$', outgoing=True))
async def go_sleep(event):
    # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return
    global is_sleeping
    is_sleeping = True
    print("Bot state changed to: Sleeping")
    await event.reply("✅ تم تفعيل وضع النوم. لن يتم معالجة الملفات وسيتم الرد برسالة الاعتذار على الرسائل الواردة.")


# Use outgoing=True for commands sent by the owner to Saved Messages
@client.on(events.NewMessage(chats='me', pattern='^\.كاعد$', outgoing=True))
async def wake_up(event):
     # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return
    global is_sleeping
    is_sleeping = False
    print("Bot state changed to: Awake")
    await event.reply("✅ تم تفعيل وضع الاستعداد. سيتم معالجة الملفات والرد برسالة الانتظار أو المجموع على الرسائل الأخرى.")


# Use outgoing=True for commands sent by the owner to Saved Messages
@client.on(events.NewMessage(chats='me', pattern='^\.م$', outgoing=True))
async def list_commands(event):
    # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return

    print("Displaying commands list.")
    # Re-format the commands list message to show current prices
    # Use the template and current global price variables
    formatted_commands_list = ( COMMANDS_LIST_MESSAGE_TEMPLATE
    ).format(
        price_lt50=PRICE_PER_PAGE_LT50,
        price_gte50=PRICE_PER_PAGE_GTE50,
        cover_cost=COVER_BINDING_COST,
        img_lt10=PRICE_PER_IMAGE_LT10,
        img_gte10=PRICE_PER_IMAGE_GTE10,
        max_size_mb=MAX_FILE_SIZE // (1024*1024) # Display size in MB
    )
    await event.reply(formatted_commands_list)


# Use outgoing=True for commands sent by the owner to Saved Messages
# Pattern: .ت<number> <value> e.g., .ت1 60
# Matches .ت followed by a digit 1-5, one or more spaces, and one or more digits.
@client.on(events.NewMessage(chats='me', pattern=r'^\.ت([1-5])\s+(\d+)$', outgoing=True))
async def adjust_price(event):
    # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return

    try:
        match = event.pattern_match
        price_type = int(match.group(1)) # Get the number after .ت (1 to 5)
        new_price_value = int(match.group(2)) # Get the numeric value

        # Update the corresponding global price variable
        global PRICE_PER_PAGE_LT50, PRICE_PER_PAGE_GTE50, COVER_BINDING_COST, PRICE_PER_IMAGE_LT10, PRICE_PER_IMAGE_GTE10

        price_name = "" # To use in the confirmation message
        if price_type == 1:
            PRICE_PER_PAGE_LT50 = new_price_value
            price_name = "سعر الصفحة (< 50 صفحة)"
        elif price_type == 2:
            PRICE_PER_PAGE_GTE50 = new_price_value
            price_name = "سعر الصفحة (>= 50 صفحة)"
        elif price_type == 3:
            COVER_BINDING_COST = new_price_value
            price_name = "ضريبة الجلاد"
        elif price_type == 4:
            PRICE_PER_IMAGE_LT10 = new_price_value
            price_name = "سعر الصورة (<= 10 صور)"
        elif price_type == 5:
            PRICE_PER_IMAGE_GTE10 = new_price_value
            price_name = "سعر الصورة (> 10 صور)"
        # else block is not strictly needed due to regex, but safe to include
        else:
             await event.reply(PRICE_UPDATE_ERROR) # Use the error message constant
             return

        print(f"Price type {price_type} updated to {new_price_value}. Name: {price_name}")
        # Use the success message template and format it
        await event.reply(PRICE_UPDATE_SUCCESS_TEMPLATE.format(price_name=price_name, new_price=new_price_value))

    except ValueError:
        # Catches if the value parsed from regex match.group(2) is not a valid integer
        print(f"Price adjustment failed: Invalid value '{match.group(2)}' for type {match.group(1)}")
        await event.reply(PRICE_UPDATE_INVALID_VALUE) # Use the invalid value message constant
    except Exception as e:
        # Catch any other unexpected error during command processing
        print(f"Error processing price adjustment command: {e}")
        traceback.print_exc() # Print full traceback for debugging
        await event.reply(PRICE_UPDATE_ERROR) # Use the general error message constant

# --- New Handler for .تفعيل command (Bot Status) ---
# Use outgoing=True for commands sent by the owner to Saved Messages
@client.on(events.NewMessage(chats='me', pattern='^\.تفعيل$', outgoing=True))
async def handle_status_command(event):
    # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return

    # Declare global variables needed for status check
    global is_sleeping, bot_start_time, user_last_interaction_time, user_prices, user_image_state

    status_message = "✅ حالة البوت: " + ("نايم (لا يعالج الملفات)" if is_sleeping else "كاعد (مستعد)") + "\n"

    # Calculate uptime
    if bot_start_time:
        uptime = datetime.now() - bot_start_time
        days = uptime.days
        seconds = uptime.total_seconds()
        hours = int(seconds // 3600 % 24)
        minutes = int(seconds // 60 % 60)
        seconds = int(seconds % 60)
        uptime_str = f"{days} يوم, {hours} ساعة, {minutes} دقيقة, {seconds} ثانية"
        status_message += f"⏰ مدة التشغيل: {uptime_str}\n"
    else:
        status_message += "⏰ مدة التشغيل: غير متوفرة (البوت بدأ للتو أو لم يتم تعيين وقت البدء)\n"

    # Count unique users interacted with (based on last interaction time, includes users with no current prices)
    unique_users_count = len(user_last_interaction_time)
    status_message += f"👥 عدد المستخدمين الذين تم التفاعل معهم (إحصائي): {unique_users_count}\n"
    status_message += f"📊 عدد المستخدمين بأسعار حالية مسجلة (دفعة طلب): {len(user_prices)}\n" # Count users with pending prices
    status_message += f"🖼️ عدد المستخدمين في حالة معالجة صورة (ينتظرون A/B): {len(user_image_state)}\n" # Count users in image state

    print(f"Status command received. Replying with status:\n{status_message}")
    await event.reply(status_message)

# --- New Handler for .فحص command (Health Check) ---
# Use outgoing=True for commands sent by the owner to Saved Messages
@client.on(events.NewMessage(chats='me', pattern='^\.فحص$', outgoing=True))
async def handle_check_command(event):
    # Ensure command comes from the bot's own account (owner)
    if bot_id is None or event.sender_id != bot_id: return

    # Declare global variables needed for check
    global client, daily_report_task, user_image_state

    check_results = []

    # Check client connection status
    if client.is_connected():
        check_results.append("✅ اتصال العميل بـ Telegram: سليم.")
    else:
        check_results.append("❌ اتصال العميل بـ Telegram: مقطوع أو غير نشط.")

    # Check daily report task status
    if daily_report_task:
        if daily_report_task.done():
            if daily_report_task.cancelled():
                check_results.append("⚠️ مهمة التقرير اليومي: تم إلغاؤها.")
            else:
                 # Task finished, but not cancelled - might indicate an error or normal completion (unlikely for infinite loop task)
                 check_results.append(f"❌ مهمة التقرير اليومي: انتهت بشكل غير متوقع.")
                 # Optional: Log the exception if task.exception() is available
                 # if daily_report_task.exception():
                 #      print("Daily report task exception:", daily_report_task.exception())
        elif daily_report_task.cancelled():
             check_results.append("⚠️ مهمة التقرير اليومي: في حالة الإلغاء أو تم إلغاؤها مؤخراً.")
        else:
            check_results.append("✅ مهمة التقرير اليومي: قيد التشغيل.")
    else:
        check_results.append("❌ مهمة التقرير اليومي: لم يتم إنشاؤها بعد.")

    # Check for old temp files
    temp_dir = "temp"
    if os.path.exists(temp_dir):
        # Use glob to find files matching the expected pattern (optional, but more specific)
        # old_temp_files = glob.glob(os.path.join(temp_dir, '*_*.*')) # Example: looks for fileid_filename.ext
        # For a simple check, just count files in the directory
        temp_files = [f for f in os.listdir(temp_dir) if os.path.isfile(os.path.join(temp_dir, f))]
        if temp_files:
            check_results.append(f"⚠️ ملفات مؤقتة متبقية في مجلد '{temp_dir}': يوجد {len(temp_files)} ملف(ات). قد يشير ذلك إلى مشاكل في التنظيف.")
        else:
            check_results.append(f"✅ مجلد '{temp_dir}': فارغ (لا توجد ملفات مؤقتة متبقية).")
    else:
         check_results.append(f"✅ مجلد '{temp_dir}': غير موجود (لا توجد ملفات مؤقتة حالياً).")


    # Check pending image states
    if user_image_state:
        check_results.append(f"⚠️ حالات صور معلقة: يوجد {len(user_image_state)} مستخدم(ين) في انتظار الرد (A/B).")
    else:
        check_results.append("✅ حالات صور معلقة: لا يوجد.")

    # Add any other specific checks if needed

    response_text = "📋 نتائج الفحص:\n" + "\n".join(check_results)

    print(f"Check command received. Replying with results:\n{response_text}")
    await event.reply(response_text)


# Commands in Private Chats with a user - For ignoring/unignoring
# These handle incoming commands *from the owner's account* in a private chat with another user
@client.on(events.NewMessage(incoming=True, pattern='^\.سماح$', func=lambda e: e.is_private and e.sender_id == bot_id))
async def mute_user(event):
    # Ensure command comes from the bot's own account (owner) in a private chat
    if bot_id is None or event.sender_id != bot_id: return

    # Declare global variable
    global ignored_users

    target_user_id = event.chat_id # The user in the private chat (an int)
    ignored_users.add(target_user_id)
    print(f"User {target_user_id} added to ignore list.")

    # Delete the command message sent by the owner
    try:
        await event.delete()
    except MessageDeleteForbiddenError:
         print(f"Cannot delete owner's command message {event.id} from chat {event.chat_id}: Forbidden")
    except Exception as e:
         print(f"Error deleting owner's command message: {e}")
         traceback.print_exc()

    # Send confirmation message in the private chat (to the user, effectively confirming to the owner)
    try:
        await event.client.send_message(event.chat_id, MUTE_SUCCESS_MESSAGE) # Use event.client
    except Exception as e:
         print(f"Error sending mute confirmation message to user {target_user_id}: {e}")
         traceback.print_exc()


@client.on(events.NewMessage(incoming=True, pattern='^\.الغاء$', func=lambda e: e.is_private and e.sender_id == bot_id))
async def unmute_user(event):
     # Ensure command comes from the bot's own account (owner) in a private chat
    if bot_id is None or event.sender_id != bot_id: return

    # Declare global variable
    global ignored_users

    target_user_id = event.chat_id # The user in the private chat (an int)
    if target_user_id in ignored_users:
        ignored_users.remove(target_user_id)
        print(f"User {target_user_id} removed from ignore list.")

        # Delete the command message sent by the owner
        try:
            await event.delete()
        except MessageDeleteForbiddenError:
             print(f"Cannot delete owner's command message {event.id} from chat {event.chat_id}: Forbidden")
        except Exception as e:
             print(f"Error deleting owner's command message: {e}")
             traceback.print_exc()

        # Send confirmation message in the private chat (to the user)
        try:
            await event.client.send_message(event.chat_id, UNMUTE_SUCCESS_MESSAGE) # Use event.client
        except Exception as e:
             print(f"Error sending unmute confirmation message to user {target_user_id}: {e}")
             traceback.print_exc()

    else:
        # If user wasn't ignored, still delete the command and send a different message
        print(f"Attempted to unmute user {target_user_id} who was not in ignore list.")
        try:
            await event.delete()
        except MessageDeleteForbiddenError:
             print(f"Cannot delete owner's command message {event.id} from chat {event.chat_id}: Forbidden")
        except Exception as e:
             print(f"Error deleting owner's command message: {e}")
             traceback.print_exc()

        try:
            await event.client.send_message(event.chat_id, USER_NOT_IGNORED_MESSAGE) # Use event.client
        except Exception as e:
             print(f"Error sending not-ignored message to user {target_user_id}: {e}")
             traceback.print_exc()


# Command in Private Chats with a user - For displaying cumulative total template
# Note: This command is for OWNER only in private chat with a user
@client.on(events.NewMessage(incoming=True, pattern='^\.عرض$', func=lambda e: e.is_private and e.sender_id == bot_id))
async def show_price_template(event):
    # Ensure command comes from the bot's own account (owner) in a private chat
    if bot_id is None or event.sender_id != bot_id: return

    # Declare global variables at the start of the function
    global global_daily_total_collected, user_prices # user_prices is read here

    target_user_id = event.chat_id # The user in the private chat (an int)

    # Calculate current cumulative total for this user from the dictionary of prices
    user_prices_dict = user_prices.get(target_user_id, {}) # Get the dict for user_id, default to empty dict if none
    total_base = sum(p[0] for p in user_prices_dict.values())
    total_cover = sum(p[1] for p in user_prices_dict.values())

    if total_base > 0 or total_cover > 0:
         reply_text = CUMULATIVE_TOTAL_MESSAGE_TEMPLATE.format(
            total_base=total_base,
            total_cover=total_cover
         )
         # Add the base total reported to the global daily total *only when the OWNER asks for it*
         # This might double count if user asks for total and then owner uses .عرض
         # Let's add here as per the code logic, acknowledging potential overlap
         global_daily_total_collected += total_base
         print(f"Added {total_base} IQD to daily total for user {target_user_id} via .عرض. Current daily total: {global_daily_total_collected}")

    else:
         reply_text = "لا توجد ملفات أو صور دراسية تم حساب سعرها لهذا المستخدم بعد آخر رد."

    # Delete the command message sent by the owner
    try:
        await event.delete()
    except MessageDeleteForbiddenError:
         print(f"Cannot delete owner's command message {event.id} from chat {event.chat_id}: Forbidden")
    except Exception as e:
         print(f"Error deleting owner's command message: {e}")
         traceback.print_exc()

    # Send the cumulative total message to the user
    try:
        await client.send_message(target_user_id, reply_text) # Send directly to the user, not as reply to command
        print(f"Displayed cumulative total for user {target_user_id} using .عرض command.")

    except Exception as e:
         print(f"Error sending cumulative total message using .عرض to user {target_user_id}: {e}")
         traceback.print_exc()


# --- Handler for ALL incoming messages (decides what to do based on state and message type) ---
# This handler runs for ALL incoming messages *not* handled by more specific commands above.
# It filters to ONLY process messages from private chats (is_private) excluding bot's self.
# Commands handled *before* this handler are: .نايم, .كاعد, .م, .ت, .تفعيل, .فحص (in 'me' chat)
# AND .سماح, .الغاء, .عرض (from bot_id in private chats - which is the owner)
# This handler is mainly for:
# 1. Sending Welcome message if needed.
# 2. Handling A/B reply for image type question.
# 3. Deleting previous status message.
# 4. Handling non-file messages (text, sticker) by sending Waiting or Apology message.
# 5. *Not* handling files/media (that's handled by handle_media which runs first if event.media is True).
@client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private and e.sender_id != bot_id))
async def handle_any_message(event):
    # Declare global variables
    global global_daily_total_collected, user_last_interaction_time, user_image_state, user_status_messages, ignored_users, is_sleeping, user_prices # Declare all globals used

    # The filter ensures this is an incoming message, from a PeerUser, and not from the bot itself.
    user_id = event.sender_id
    chat_id = event.chat_id # In private chat, chat_id is the user_id (an int)
    current_time = datetime.now() # Get current time

    # --- Check if user is ignored ---
    if user_id in ignored_users:
        print(f"Ignoring message from user {user_id} as they are in the ignore list.")
        return # Stop processing if ignored

    # --- Welcome Message Logic ---
    last_interaction = user_last_interaction_time.get(user_id)
    send_welcome = False

    # Send welcome if first interaction, or if cooldown period has passed
    # Note: This logic is now inside handle_any_message, which runs for ALL private messages from user.
    # This might send welcome more often if user sends many non-file messages.
    # A better place might be a separate handler for first message *or* move logic to handle_media too.
    # For now, keeping it here as per the original structure of the 977-line code.
    if last_interaction is None or (current_time - last_interaction) >= WELCOME_COOLDOWN:
        send_welcome = True

    if send_welcome:
        try:
            # Use event.client for sending messages within handlers
            await event.client.send_message(chat_id, WELCOME_MESSAGE)
            # Update the last interaction time ONLY AFTER sending the welcome message successfully
            user_last_interaction_time[user_id] = current_time
            print(f"Sent welcome message to user {user_id}.")
        except Exception as e:
             print(f"Error sending welcome message to user {user_id}: {e}")
             traceback.print_exc()
             # Pass - continue processing even if welcome fails
    else:
         # If no welcome message was sent, just update the last interaction time
         user_last_interaction_time[user_id] = current_time


    # --- Check if user is waiting for Image Reply (A/B) ---
    # This handles text replies "A" or "B" in response to the bot's question message.
    # This block MUST be checked *before* handling generic non-file messages.
    if user_id in user_image_state and event.raw_text: # Check if state exists and message has text
        reply_text = event.raw_text.strip().upper()
        state = user_image_state.get(user_id) # Get state without popping yet

        # Check if the message is a reply to the specific question message AND the text is A or B
        if state and event.reply_to_msg_id == state.get('question_message_id') and reply_text in ['A', 'B']:
            print(f"Received valid image type reply '{reply_text}' from user {user_id}.")
            state = user_image_state.pop(user_id) # Pop state now that reply is valid

            # Attempt to delete the user's reply message (A or B)
            try:
                await event.delete()
            except MessageDeleteForbiddenError:
                print(f"Cannot delete user's A/B reply message {event.id} in chat {chat_id}: Forbidden")
            except Exception as e:
                print(f"Error deleting user's A/B reply message: {e}")
                traceback.print_exc()

            # Attempt to delete the bot's question message
            if state.get('question_message_id'):
                try:
                    # Use event.client for deleting messages within handlers
                    await event.client.delete_messages(chat_id, state['question_message_id'])
                except MessageDeleteForbiddenError:
                     print(f"Cannot delete bot's question message {state['question_message_id']} in chat {chat_id}: Forbidden")
                except Exception as e:
                     print(f"Error deleting bot's question message: {e}")
                     traceback.print_exc()

            # Process the reply based on A or B
            if reply_text == 'A':
                # Process as Study Image
                original_msg_id = state.get('original_message_id')
                image_count = state.get('image_count', 0)
                if image_count > 0 and original_msg_id is not None:
                    # Calculate price for study images (calculate_price returns (base, cover) tuple)
                    base_price, cover_price = calculate_price(image_count, is_image=True)

                    # Store price in user_prices using the original message ID
                    # Use setdefault to ensure the inner dict exists
                    user_prices.setdefault(user_id, {})[original_msg_id] = (base_price, cover_price) # Store as dict {msg_id: (base, cover)}
                    print(f"Added {base_price} IQD (study image price) for user {user_id}, msg_id {original_msg_id}")

                    # Send confirmation to user
                    # Use event.client for sending messages within handlers
                    await event.client.send_message(chat_id, IMAGE_STUDY_CONFIRMATION.format(count=image_count, price=base_price))

                    # Send the cumulative total after adding study image price
                    # This will be sent *after* the study image confirmation
                    await send_cumulative_total(user_id, chat_id)


                else:
                     # Should not happen if image_count/original_msg_id is stored correctly, but as a fallback
                     print(f"Error processing study image for user {user_id}: Invalid state data (count={image_count}, original_id={original_msg_id})")
                     await event.client.send_message(chat_id, "❌ حدث خطأ في معالجة صورك الدراسية.")


            elif reply_text == 'B':
                # Process as Personal Image - No price calculation here, just inform user to wait for owner
                print(f"User {user_id} selected personal image for msg_id {state.get('original_message_id')}.")
                # Use event.client for sending messages within handlers
                await event.client.send_message(chat_id, IMAGE_PERSONAL_CONFIRMATION)

            # Exit handler after processing a valid A/B reply
            return


        # If user is in image state, but the message wasn't a valid A/B reply to the correct message,
        # the state is NOT popped. Processing continues below for this message.


    # --- Delete previous status message for this user if exists ---
    # This applies to any non-ignored message from the user (file or not) while a status message is active
    # This runs AFTER checking for and handling valid A/B replies.
    # So, if a user sends a normal message *while* the A/B question is pending,
    # the A/B handling above does NOT return, and this block runs, deleting the status message (like WAITING_MESSAGE).
    # This is acceptable behavior as the new message replaces the old status indication.
    if user_id in user_status_messages:
        try:
            await user_status_messages[user_id].delete()
            print(f"Deleted previous status message for user {user_id}.")
        except MessageDeleteForbiddenError:
            print(f"Cannot delete previous status message for user {user_id}: Forbidden in chat {chat_id}")
        except Exception as e:
             print(f"Error deleting previous status message for user {user_id}: {e}")
             traceback.print_exc()
        finally:
            # Always remove from dict even if delete fails
            del user_status_messages[user_id]


    # --- Handle non-file messages (text, sticker, etc.) ---
    # This block ONLY runs if the message is NOT a file (event.file is False, which means event.media is False or not a document/photo sent as file)
    # AND it wasn't a valid A/B reply (handled above and returned).
    # Ignored users are filtered at the very beginning.
    # The total is NOT sent here anymore.
    if not event.file: # Check if event.file is False (this should include text, stickers, etc. and possibly some media not sent as file)
        if is_sleeping:
            # If bot is sleeping, send apology message.
            # This block is reached for any non-file/non-handled-media message from a non-ignored user when bot is sleeping.
            print(f"Bot is sleeping, sending apology to user {user_id} for non-file message.")
            # Use event.client for sending messages within handlers
            new_status_message = await event.client.send_message(chat_id, APOLOGY_MESSAGE)
            user_status_messages[user_id] = new_status_message # Store for later deletion

        else: # Bot is awake, and message is NOT a file
            # User sent a non-file message (text, sticker, etc.), likely just sending text or sticker.
            # We only send the WAITING_MESSAGE.
            print(f"User {user_id} sent non-file message. Sending waiting message.")
            reply_text = WAITING_MESSAGE

            # Send the waiting message
            # Use event.client for sending messages within handlers
            new_status_message = await event.client.send_message(chat_id, reply_text)
            user_status_messages[user_id] = new_status_message # Store for later deletion

        # No StopPropagation needed here.

    # If message IS a file (event.file is True) and NOT ignored and NOT a valid A/B reply,
    # this handler does not process it further, allowing handle_media to process it.


# --- Handler for INCOMING MEDIA messages (images, documents, etc.) ---
# This handler runs only if the message has media, is in a private chat, and is not from the bot itself.
# Note: This handler will be triggered *before* handle_any_message if event.media is True.
@client.on(events.NewMessage(incoming=True, func=lambda e: e.media and e.is_private and e.sender_id != bot_id))
async def handle_media(event):
    # Declare global variables
    global is_sleeping, ignored_users, user_status_messages, user_image_state, user_prices # Declare all globals used

    # The filter ensures this is an incoming message with media,
    # from a PeerUser, and not from the bot itself.

    user_id = event.sender_id
    chat_id = event.chat_id # In private chat, chat_id is the user_id (an int)

    # --- Check if bot is sleeping FIRST ---
    if is_sleeping:
        print(f"Bot is sleeping. Ignoring media from user {user_id}.")
        try:
             # Send apology message if bot is sleeping, replacing any previous status message
            if user_id in user_status_messages:
                 try:
                      # Use event.client for deleting messages within handlers
                      await user_status_messages[user_id].delete()
                 except Exception: pass # Ignore delete errors here
                 finally:
                      del user_status_messages[user_id]

            # Use event.client for sending messages within handlers
            new_status_message = await event.client.send_message(chat_id, APOLOGY_MESSAGE)
            user_status_messages[user_id] = new_status_message # Store for later deletion

        except Exception as e:
             print(f"Error sending sleeping apology message to user {user_id}: {e}")
             traceback.print_exc()
        return # Stop processing this media if bot is sleeping

    # --- Check if user is ignored ---
    if user_id in ignored_users:
        print(f"Ignoring media from user {user_id} as they are in the ignore list.")
        return # Stop processing if ignored


    # --- Delete previous status message for this user if exists ---
    # This applies to any media message from the user while a status message is active
    if user_id in user_status_messages:
        try:
            await user_status_messages[user_id].delete()
            print(f"Deleted previous status message for user {user_id}.")
        except MessageDeleteForbiddenError:
            print(f"Cannot delete previous status message for user {user_id}: Forbidden in chat {chat_id}")
        except Exception as e:
             print(f"Error deleting previous status message for user {user_id}: {e}")
             traceback.print_exc()
        finally:
            # Always remove from dict even if delete fails
            del user_status_messages[user_id]


    # Check file size using event.file which should exist for documents and photos sent as files
    # This check relies on event.file.size being available.
    if event.file and event.file.size > MAX_FILE_SIZE:
        print(f"File size limit exceeded for user {user_id}, file {getattr(event.file, 'name', 'N/A')} ({event.file.size} bytes). Limit: {MAX_FILE_SIZE} bytes.")
        try:
            await event.reply(FILE_SIZE_ERROR_MESSAGE)
        except Exception as e:
            print(f"Error sending size limit message to user {user_id}: {e}")
            traceback.print_exc()
        return # Stop processing this oversized file

    # Determine if it's an image or a document type we handle
    # Use isinstance with imported types for more robust checking
    is_image = isinstance(event.media, MessageMediaPhoto)
    is_document = isinstance(event.media, MessageMediaDocument) # Check if it's a general document type

    # Get filename and extension ONLY if it's a document (not a photo)
    filename = 'unknown_file'
    ext = ''
    is_handled_document = False # Initialize flag
    if is_document and event.media.document:
         # Access attributes via event.media.document (the TLObject)
         # Use a list comprehension and next() for safer attribute access
         filename_attr = next((attr for attr in getattr(event.media.document, 'attributes', []) if getattr(attr, 'file_name', None)), None)
         if filename_attr:
              filename = filename_attr.file_name.lower()
              ext = os.path.splitext(filename)[1]
         # Check if the document has a valid extension for processing
         if ext in ['.pdf', '.docx', '.pptx']:
             is_handled_document = True


    # --- If it's an Image (MessageMediaPhoto) ---
    if is_image:
        print(f"Received image (MessageMediaPhoto) from user {user_id} (Msg ID: {event.id}).")
        # For simplicity, assume 1 image per event here. Handling albums correctly requires events.Album handler.
        image_count = 1 # Assume 1 image per event for now

        # Clear any previous pending image state for this user if it somehow wasn't cleaned
        if user_id in user_image_state:
             print(f"Clearing stale image state for user {user_id} before asking new question for msg ID {event.id}.")
             # Attempt to clean up the previous question message if it exists
             state_to_clear = user_image_state[user_id]
             question_msg_id_to_clear = state_to_clear.get('question_message_id')
             if question_msg_id_to_clear:
                 try:
                      # Use event.client for deleting messages within handlers
                      await event.client.delete_messages(user_id, question_msg_id_to_clear)
                 except Exception as e:
                      print(f"Error clearing previous question message {question_msg_id_to_clear}: {e}")
                      traceback.print_exc()
             del user_image_state[user_id] # Always delete the state


        # Store state for A/B question, including the original message ID of the image
        user_image_state[user_id] = {'image_count': image_count, 'question_message_id': None, 'original_message_id': event.id}
        print(f"Stored pending image state for user {user_id}, original msg ID {event.id}.")

        # Send the A/B question as a reply to the image
        try:
            # Use event.reply for sending messages within handlers, makes it a reply
            question_msg = await event.reply(IMAGE_QUESTION_MESSAGE)
            user_image_state[user_id]['question_message_id'] = question_msg.id # Store the ID of the question message
            print(f"Sent image question message {question_msg.id} to user {user_id} for image (Original Msg ID: {event.id}).")
        except Exception as e:
            print(f"Error sending image question message to user {user_id}: {e}")
            traceback.print_exc()
            # Clear the state if sending the question fails critically
            if user_id in user_image_state:
                 del user_image_state[user_id]
            await event.reply("❌ حدث خطأ في معالجة الصورة. يرجى المحاولة مرة أخرى.")

        # No StopPropagation needed here, as the handler function completes.

    # --- If it's a Handled Document (MessageMediaDocument with .pdf, .docx, .pptx extension) ---
    elif is_handled_document: # This is true if it's a Document AND has a handled extension
        print(f"Received handled document '{filename}' from user {user_id} (Msg ID: {event.id}).")
        # 2. Send "Calculating..." message immediately as a reply
        calculating_message = None
        try:
            # Use event.reply for sending messages within handlers
            calculating_message = await event.reply(CALCULATING_MESSAGE)
            print(f"Sent calculating message {calculating_message.id} to user {user_id} for file {filename} (Msg ID: {event.id})")
        except Exception as e:
             print(f"Error sending calculating message to user {user_id}: {e}")
             traceback.print_exc()


        file_path = None # Initialize file_path outside try for finally block

        try:
            # 3. Download the file
            os.makedirs("temp", exist_ok=True) # Ensure temp directory exists
            # Use event.file.id for unique name based on document/photo ID, or event.media.document.id
            # event.file.id is usually reliable for files/documents/photos sent as files
            # Construct file_path safely ensuring it has extension
            file_path = os.path.join("temp", f"{event.file.id}_{filename if filename != 'unknown_file' else 'file_without_name'}{ext}")
            # Download media might be slow for large files, but happens after the "calculating" message.
            await event.download_media(file_path)
            print(f"Downloaded file {filename} to {file_path}")


            # 4. Count pages/slides using the non-blocking function
            # Pass file_path and ext. count_pages_for_document only needs these now.
            pages = await count_pages_for_document(file_path, ext)
            if pages == 0:
                 # Raising ValueError with a specific string helps differentiate in except block
                 raise ValueError("failed to count pages or file is corrupt")
            print(f"Counted {pages} pages for file {filename}")


            # 5. Calculate prices for the current file (calculate_price returns (base, cover) tuple)
            base_price_file, cover_price_file = calculate_price(pages, is_image=False)
            print(f"Calculated prices for file: Base={base_price_file}, Cover={cover_price_file}")

            # 6. Delete the "Calculating..." message now that calculation is done
            if calculating_message:
                try:
                    # Use event.client for deleting messages within handlers
                    await event.client.delete_messages(chat_id, calculating_message.id)
                    print("Deleted calculating message.")
                except MessageDeleteForbiddenError:
                    print(f"Cannot delete calculating message {calculating_message.id} from chat {event.chat_id}: Forbidden")
                except Exception as e_del:
                     print(f"Error deleting calculating message {calculating_message.id} on error from chat {chat_id}: {e_del}")
                     traceback.print_exc()


            # 7. Reply with the price of the current file AND confirmation
            # This reply replaces the "Calculating..." message location effectively
            await event.reply(
                f"📄 عدد الصفحات/الشرائح: {pages}\n"
                f"💰 السعر بدون جلاد: {base_price_file} دينار\n"
                f"🏷️ السعر مع جلاد: {cover_price_file} دينار\n"
                f"✅ تم إضافة هذا السعر للمجموع الكلي الخاص بك." # Confirmation line
            )
            print(f"Sent file price and confirmation to user {user_id}.")


            # 8. Store prices for the current file for later total calculation and deletion handling
            # Use setdefault to ensure the inner dict {msg_id: (price)} exists for the user
            user_prices.setdefault(user_id, {})[event.id] = (base_price_file, cover_price_file) # Use event.id (message ID) as the key
            print(f"Stored prices for user {user_id}, msg_id {event.id}. Current user_prices state: {user_prices.get(user_id)}")

            # 9. Send the cumulative total after processing this file
            # This will be sent *after* the file price confirmation
            await send_cumulative_total(user_id, chat_id)


        except ValueError as ve: # Catch the specific ValueError raised for counting pages
             print(f"Failed to count pages for user {user_id}, file {filename}: {ve}")
             traceback.print_exc()
             # Attempt to delete calculating message even on counting error
             if calculating_message:
                 try:
                     # Use event.client for deleting messages within handlers
                     await event.client.delete_messages(chat_id, calculating_message.id)
                 except Exception: pass # Ignore delete errors here to avoid error loops
             # Reply with the specific error message for counting pages
             await event.reply(COUNT_PAGES_ERROR_MESSAGE)

        except Exception as e:
            # Handle any other unexpected errors during processing (download, calculation, etc.)
            print(f"An unexpected error occurred for user {user_id}, file {filename}: {e}")
            traceback.print_exc() # Print full traceback
            # Attempt to delete calculating message even on general error
            if calculating_message:
                 try:
                     # Use event.client for deleting messages within handlers
                     await event.client.delete_messages(chat_id, calculating_message.id)
                 except MessageDeleteForbiddenError:
                     print(f"Cannot delete calculating message {calculating_message.id} on error from chat {event.chat_id}: Forbidden")
                 except Exception as e_del:
                     print(f"Error deleting calculating message {calculating_message.id} on error from chat {chat_id}: {e_del}")
                     traceback.print_exc()

            # Reply with the general processing error message
            await event.reply(PROCESSING_ERROR_MESSAGE)

        finally:
            # 10. Clean up the temporary file always, regardless of success or failure
            # Only attempt to remove if file_path was successfully set during download
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    print(f"Cleaned up file {file_path}.")
                except Exception as e:
                    print(f"Error cleaning up file {file_path}: {e}")
                    traceback.print_exc()

    # --- If it's other media type (Video, Voice, Sticker, Unsupported Document Type, etc.) ---
    # This block is reached if event.media is True, but it's neither a Photo NOR a handled Document type/extension.
    else:
        print(f"Received unsupported media type ({type(event.media).__name__}) or unsupported document extension ('{ext}') from user {user_id} (Msg ID: {event.id}).")
        try:
             # Use event.reply for sending messages within handlers
             await event.reply(FILE_TYPE_ERROR_MESSAGE) # Use the more specific file type error message
        except Exception as e:
             print(f"Error sending unsupported media message to user {user_id}: {e}")
             traceback.print_exc()

    # No StopPropagation needed here.


# --- REMOVED: Handler for messages from groups/channels ---
# This handler is removed to prevent any response in groups/channels.
# The filter 'func=lambda e: e.is_private' on handle_any_message and handle_media
# already ensures they only run in private chats.
# @client.on(events.NewMessage(incoming=True, func=lambda e: not e.is_private))
# async def handle_group_message(event):
#      pass # Function removed


# --- Handler for deleted messages ---
# This handler runs for deleted messages. It uses event.chat_id to find the user.
@client.on(events.MessageDeleted())
async def handler_message_deleted(event):
    # event.deleted_ids is a list of IDs if multiple were deleted
    deleted_ids = event.deleted_ids

    # event.chat_id might be available depending on context.
    # For deletions in private chats where user_prices is relevant, chat_id should be the user_id (an int).
    chat_id = event.chat_id

    # --- Start try block to catch errors within this handler ---
    try:
        # Declare global variables
        global user_prices, user_image_state # Declare all globals used

        # We only care about deletions in private chats where we track user_prices
        # The chat_id for PeerUser (private chat) is an int, which is what we use as keys in user_prices
        # Ensure chat_id is not None and is an integer (private chat user ID)
        if chat_id is not None and isinstance(chat_id, int):
            prices_changed = False
            # Check if this user has any price history tracked
            if chat_id in user_prices:
                # user_prices[chat_id] is a dict {message_id: (base_price, cover_price)}
                for deleted_id in deleted_ids:
                    # Check if the deleted message ID exists as a key in the user's prices dictionary
                    if deleted_id in user_prices[chat_id]:
                        # Get the price before removing (optional, for logging)
                        deleted_price_tuple = user_prices[chat_id][deleted_id]
                        # Remove the price entry associated with this message ID
                        del user_prices[chat_id][deleted_id]
                        prices_changed = True
                        print(f"Removed price {deleted_price_tuple} for message {deleted_id} from user {chat_id} due to deletion.")
                # Check if deleting the price left the user's dictionary empty, and remove the user entry
                # This check needs to be outside the for loop, after checking all deleted_ids
                if chat_id in user_prices and not user_prices[chat_id]: # Check if user_prices[chat_id] is empty
                     del user_prices[chat_id]
                     print(f"Removed empty price history entry for user {chat_id}.")

            # If any prices were changed (items deleted)
            # Send the updated cumulative total.
            if prices_changed:
                 # Send the cumulative total after deletion update
                 # We need to send it to the chat where deletion happened (chat_id)
                 # Call the shared function to send total
                 await send_cumulative_total(chat_id, chat_id)


        # Also check and clean up user_image_state if the question message itself was deleted
        # (Although unlikely a user would delete the bot's question message)
        # Check if the deleted ID is the question message ID for this user
        if chat_id is not None and isinstance(chat_id, int) and chat_id in user_image_state and user_image_state[chat_id].get('question_message_id') in deleted_ids:
             print(f"Bot's image question message {user_image_state[chat_id]['question_message_id']} was deleted for user {chat_id}. Clearing image state.")
             del user_image_state[chat_id]

        elif chat_id is None:
             # If chat_id is not available in the event, we cannot reliably know the user/chat
             print(f"Could not determine chat_id for deleted message(s): {deleted_ids}")
             # Cannot process if chat_id is unknown

    # --- End of try block ---

    # --- Start except block matching the try block ---
    # This catchall should be indented at the same level as the 'try:' line above
    except Exception as e:
        print(f"Error handling MessageDeleted event for IDs {deleted_ids} in chat {chat_id}: {e}")
        traceback.print_exc()

    # Note: No finally block needed here


# --- Bot startup and shutdown logic ---
async def main():
    # Declare global variables
    global bot_id, bot_start_time, daily_report_task # Declare all globals used

    # Check for SESSION_STRING before even trying to start
    if SESSION_STRING == 'ضع_سلسلة_جلستك_هنا' or not SESSION_STRING or SESSION_STRING.strip() == '':
        print("CRITICAL ERROR: Please replace 'ضع_سلسلة_جلستك_هنا' with your actual session string.", file=sys.stderr)
        # Send critical error notification if possible before exiting
        # This requires a separate client or very careful handling, best left to wrapper if used.
        # For single script, just exit.
        sys.exit(1) # Exit with an error code


    try:
        print("⏳ يتم بدء تشغيل البوت...")
        # Start the client
        await client.start()

        # Get bot's own info and set bot_id
        me = await client.get_me()
        bot_id = me.id # Set bot_id after successful start
        bot_start_time = datetime.now() # Set the bot's start time
        print(f"✅ البوت شغال وينتظر الملفات والاوامر (Bot ID: {bot_id})...")

        # Ensure temp directory exists on startup
        if not os.path.exists("temp"):
             os.makedirs("temp")
             print("Created 'temp' directory.")

        # Start the periodic daily report task concurrently
        # Create task AFTER client.start() and bot_id is set
        # Store the task object in the global variable
        daily_report_task = client.loop.create_task(report_daily_total())
        print("⏱️ تم بدء مهمة التقرير اليومي...")

        # Run until disconnected (or error)
        # This is the main loop that keeps the bot running and processing events.
        # FIX: Corrected method name
        await client.run_until_disconnected()
        print("🔴 تم إنهاء run_until_disconnected بشكل طبيعي.") # Should happen on client.disconnect()

    except SystemExit:
         # Catch SystemExit specifically if sys.exit() is called (like our SESSION_STRING check)
         print("Detected SystemExit. Shutting down gracefully.")
         # No need to call sys.exit(e.code) here, it's already exiting
         # Notification for SystemExit might not be possible if the exit is too fast/early

    except Exception as e:
        # Catch any other exception during startup or runtime that run_until_disconnected might not catch
        # This handles errors that crash the event loop outside of specific event handlers.
        print(f"💥 حدث خطأ غير متوقع أدى إلى توقف البوت: {e}", file=sys.stderr) # Log error to stderr
        traceback.print_exc() # Print full traceback for debugging
        # --- Send notification about the crash ---
        error_message = f"💥 حدث خطأ غير متوقع أدى إلى توقف البوت: {e}\n\nيرجى التحقق من السجلات وإعادة تشغيل البوت."
        print("Attempting to send crash notification...")
        # MODIFIED: Use the existing client's loop to schedule the notification sending
        # This will work *if* the event loop hasn't been fully destroyed by the crash.
        try:
            # Schedule the send_notification coroutine as a task in the client's loop
            client.loop.create_task(send_notification(error_message))
            print("Crash notification task scheduled.")
            # Wait briefly for the task to potentially start before exiting
            await asyncio.sleep(2)
        except Exception as notify_e:
            # This catch handles failure in scheduling the task, not failure within send_notification itself
            print(f"❌ فشل جدولة مهمة إرسال تنبيه العطل: {notify_e}", file=sys.stderr)
            traceback.print_exc()
        # --------------------------------------


    finally:
        # This block always runs when the try/except block is exited.
        # It's used for cleanup (disconnecting client, cancelling tasks).

        # The main client connection might be broken after a crash, or the loop closed.
        # We don't need to explicitly disconnect the main client here if asyncio.run exited,
        # as its resources are likely being cleaned up by the event loop termination.
        # Also, attempting to await disconnect after a crash might fail.
        pass # Removed main client disconnect

        # The daily report task ran in the main loop, so it's stopped/gone when main loop exits.
        # Attempting to cancel/await it here might cause errors if the loop is closed.
        pass # Removed task cancellation

        # Note: All in-memory data (user_prices, states, totals, etc.) is lost when the script process exits.


    print("✅ تم إيقاف البوت بشكل نهائي.")


# Entry point of the script
if __name__ == '__main__':
    # The initial check for SESSION_STRING can be done here as well,
    # although it's also inside main(). Redundant check is harmless.
    if SESSION_STRING == 'ضع_سلسلة_جلستك_هنا' or not SESSION_STRING or SESSION_STRING.strip() == '':
        print("CRITICAL ERROR: Please replace 'ضع_سلسلة_جلستك_هنا' with your actual session string.", file=sys.stderr)
        sys.exit(1) # Exit immediately if session string is not set

    # Run the main async function using asyncio.run
    # This starts the async event loop and runs the main function until it completes.
    # It will attempt to send a notification if an unhandled exception occurs within main().
    # This approach does NOT provide automatic restart if the script crashes.
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Handle manual interruption (Ctrl+C) gracefully outside of asyncio.run
        print("\nالسكريبت تم إيقافه يدوياً (KeyboardInterrupt).")
        # The finally block in main() might run depending on when the interrupt happens.
    except Exception as e:
        # Catch any exceptions that escape asyncio.run itself (less common)
        print(f"💥 خطأ غير معالج خارج asyncio.run: {e}", file=sys.stderr)
        traceback.print_exc()